<?php 
/*
 *	Made by Samerton
 *  http://worldscapemc.co.uk
 *
 *  License: MIT
 * Copyright (c) 2016 Samerton
 */

// Language file for "Vote" addon

$vote_language = array(
	'vote' => 'Vote',
	'vote_icon' => '', // Icon to display in navbar before text
	'top_voters' => 'Top voters list coming soon'
);
